# 《死灵军团》完整项目说明

本文档记录当前项目中游戏的全部可见内容、文件组成、前端结构、交互方式、核心玩法、Canvas 渲染、数据状态、角色数值、敌人生成、复活机制、排行榜、技能系统与已知实现细节。

记录对象是当前工作区内的游戏源码与素材文件：

- `douyinsl/index.html`
- `douyinsl/assets/necromancer-legion-poster-clean.png`
- `douyinsl/assets/necromancer-legion-poster-start.png`
- `douyinsl/assets/necromancer-legion-poster.png`

`.git` 目录属于版本库元数据，不属于游戏运行资源；本文只描述游戏项目文件。

## 一、项目总体

这是一个纯前端、单文件主体的竖屏 Canvas 小游戏。游戏标题是《死灵军团》。玩家控制屏幕中央的死灵法师，通过鼠标或触摸拖动位置，躲避从边缘刷新的敌人。己方骷髅会自动攻击敌人。敌人死亡后会留下尸体，玩家让死灵法师靠近尸体并点击画面，可以把尸体复活成新的己方单位。普通模式目标是击杀 500 个怪物；无限模式没有通关结算，死亡后按击杀数、等级和存活时间记录成绩。

项目不依赖构建工具、框架、npm 包或后端服务。直接用浏览器打开 `douyinsl/index.html` 即可运行。排行榜保存在浏览器 `localStorage` 中，只在当前浏览器本机有效。

## 二、文件清单

| 文件 | 大小 | 作用 | 是否被游戏代码直接引用 |
|---|---:|---|---|
| `douyinsl/index.html` | 89349 字节 | 游戏唯一运行入口，包含 HTML、CSS、Canvas 绘制和全部 JavaScript 逻辑 | 是 |
| `douyinsl/assets/necromancer-legion-poster-start.png` | 2029574 字节 | 竖屏开始菜单背景图，尺寸 750x1334，带游戏标题和操作示意 | 是 |
| `douyinsl/assets/necromancer-legion-poster-clean.png` | 3634816 字节 | 宣传海报图，尺寸 1024x1536，带完整玩法卖点和底部功能文案 | 否 |
| `douyinsl/assets/necromancer-legion-poster.png` | 2782076 字节 | 宣传海报图，尺寸 1024x1536，含“前十名通关奶茶一杯”横幅 | 否 |

三个 PNG 均为死灵暗黑题材视觉资产。当前 CSS 只引用 `assets/necromancer-legion-poster-start.png`，用作开始页全屏背景。其余两张更像宣传图或备选图，代码中没有加载。

## 三、运行方式

游戏是静态页面，运行方式有两种：

```text
直接双击 douyinsl/index.html
```

或使用任意静态服务器托管整个 `douyinsl` 目录。因为资源引用是相对路径 `assets/necromancer-legion-poster-start.png`，只要保持 `index.html` 和 `assets` 目录的相对位置不变即可。

不需要数据库、接口、编译、打包或安装依赖。

## 四、页面结构

`index.html` 的页面结构很集中：

- `<head>` 中设置 UTF-8、移动端 viewport、标题和全部 CSS。
- `<body>` 中只有一个游戏容器 `#gameContainer`。
- `#gameContainer` 内包含一个 Canvas 和一层绝对定位 UI。
- `<script>` 中包含全部游戏配置、状态、类、函数和主循环。

DOM 层主要负责覆盖式 UI，真正的游戏单位、移动、碰撞、攻击、尸体和特效都绘制在 Canvas 上。

### HTML 节点

| 节点 | 作用 |
|---|---|
| `#gameContainer` | 375:667 竖屏比例容器，负责限制游戏画面尺寸 |
| `#gameCanvas` | 主游戏画布，逻辑尺寸固定为 375x667 |
| `#ui` | 覆盖在 Canvas 上方的 UI 层，不拦截普通指针事件 |
| `#armyCount` | 左上角军队数量显示 |
| `#waveInfo` | 右上角波次显示 |
| `#killCount` | 右上角击杀显示 |
| `#xpPanel` | 无限模式等级与技能状态面板 |
| `#xpText` | 显示等级和经验，例如 `Lv 1 0/43` |
| `#skillText` | 显示已获得技能状态 |
| `#killProgress` | 顶部进度条轨道，普通模式显示击杀进度，无限模式显示经验进度 |
| `#killProgressFill` | 进度条填充 |
| `#bottomTip` | 底部动态提示语 |
| `#startPopup` | 开始菜单，全屏覆盖，默认显示 |
| `#winPopup` | 普通模式通关弹窗 |
| `#losePopup` | 失败弹窗 |
| `#leaderboardPopup` | 排行榜弹窗 |
| `#skillPopup` | 无限模式等级突破时的技能选择弹窗 |
| `#skillOptions` | 技能选项按钮容器 |

### 开始菜单内容

开始菜单显示：

- 标语：`召唤亡者 · 横扫战场`
- 标题：`死灵军团`
- 说明：`从 5 个小兵起步，点击尸体召唤新的士兵，组建你的死灵大军。`
- 三个卖点格：`5 初始小兵`、`点击 复活尸体`、`500 击杀目标`
- 三个按钮：`开始游玩`、`无限模式`、`排行榜`
- 底部提示：`竖屏体验最佳 · 鼠标 / 触摸均可操作`

按钮行为：

- `开始游玩` 调用 `startGame('normal')`
- `无限模式` 调用 `startGame('endless')`
- `排行榜` 调用 `openLeaderboard()`

### 胜负与排行榜弹窗

通关弹窗显示“恭喜通关”和“你的军团吞没了整片战场。”，提供“再来一局”和“主菜单”。

失败弹窗显示“游戏结束”和“死灵法师被敌人近身，军团溃散。”，同样提供“再来一局”和“主菜单”。

排行榜弹窗显示普通和无限两列。本机暂无成绩时显示“暂无记录”。

## 五、布局与视觉设计

页面是移动优先的竖屏布局。`#gameContainer` 使用：

```css
width: min(375px, 100vw, calc(100vh * 375 / 667));
aspect-ratio: 375 / 667;
```

这让画面保持 375:667 的逻辑比例，同时适配浏览器宽高。Canvas 的 CSS 尺寸填满容器，但 Canvas 内部逻辑坐标仍固定为 375x667。

整体视觉是暗绿色、金色、青绿色和黑色组成的死灵幻想风格。页面背景是径向光晕加深色线性渐变，游戏容器有细金边和阴影。HUD 使用半透明深色面板、金色描边、模糊背景和文字阴影。开始菜单以海报图为底，通过暗色渐变遮罩、扫描光线、金属按钮和发光边框强化暗黑题材。

主要 CSS 模块：

- 全局重置：取消 margin/padding，关闭选择文本，设置 `touch-action: manipulation`。
- `body`：居中容器，隐藏滚动条，禁止页面溢出。
- `#gameContainer`：固定比例竖屏画框。
- `#gameCanvas`：显示主画面，鼠标指针为 pointer。
- `#ui`：覆盖式 UI 层，默认不接收指针事件。
- HUD：`#armyCount`、`#waveInfo`、`#killCount` 使用统一卡片样式。
- 进度条：`#killProgress` 和 `#killProgressFill`。
- 动态提示：`#bottomTip`，可切换 `.ready` 状态。
- 弹窗：`.popup`、`.popup button`、`.popup-actions`。
- 开始页：`#startPopup`、`.start-content`、`.menu-panel`、`.menu-stats`、`.menu-actions`。
- 排行榜：`.leaderboard-panel`、`.leaderboard-columns`、`.leaderboard-list`。
- 技能选择：`.skill-options`、`.skill-option`。
- 动画：`scanGlow` 和 `buttonShine`。

## 六、核心配置

`CONFIG` 是游戏的集中配置对象。它定义画布尺寸、单位数值、生成速度、经验、技能、排行榜等参数。

| 配置 | 当前值 | 含义 |
|---|---:|---|
| `CANVAS_WIDTH` | 375 | Canvas 逻辑宽度 |
| `CANVAS_HEIGHT` | 667 | Canvas 逻辑高度 |
| `NECROMANCER_X` | 187.5 | 死灵法师初始 X |
| `NECROMANCER_Y` | 333.5 | 死灵法师初始 Y |
| `CORPSE_LIFETIME` | 8000 | 尸体存在 8 秒 |
| `ATTACK_COOLDOWN` | 500 | 近战基础攻击间隔，毫秒 |
| `ATTACK_RANGE` | 12 | 近战额外攻击距离 |
| `MOVEMENT_SCALE` | 0.35 | 所有单位基础速度缩放 |
| `NECROMANCER_FOLLOW_SENSITIVITY` | 0.512 | 死灵法师跟随鼠标/触摸点的插值比例 |
| `NECROMANCER_SPEED` | 4 | 死灵法师构造参数中的速度 |
| `MAX_ARMY` | 20 | 最大己方军队数量 |
| `RANGER_RANGE` | 120 | 远程骷髅攻击距离 |
| `RANGER_COOLDOWN` | 800 | 远程骷髅基础攻击间隔 |
| `MEDIUM_SIZE` | 24 | 中型骷髅尺寸 |
| `RANGER_SIZE` | 14 | 远程骷髅尺寸 |
| `TOTAL_KILLS` | 500 | 普通模式通关击杀数 |
| `SPAWN_INTERVAL` | 900 | 刷怪周期，毫秒 |
| `BASE_ENEMIES_PER_SPAWN` | 1 | 每次刷怪基础数量 |
| `MAX_ENEMIES_PER_SPAWN` | 3 | 每次刷怪基础上限 |
| `SPAWN_COUNT_MULTIPLIER` | 1.8 | 刷怪数量总倍率 |
| `ENEMY_SPEED_GROWTH_PER_WAVE` | 0.08 | 每波敌人速度成长 |
| `ENEMY_SPEED_GROWTH_PER_MINUTE` | 0.06 | 每分钟敌人速度成长 |
| `ENEMY_COUNT_GROWTH_PER_WAVE` | 0.25 | 每波敌人数量成长 |
| `ENEMY_COUNT_GROWTH_PER_MINUTE` | 0.15 | 每分钟敌人数量成长 |
| `MAX_ACTIVE_ENEMIES` | 28 | 普通模式最大在场敌人 |
| `ENDLESS_MAX_ACTIVE_ENEMIES` | 45 | 无限模式最大在场敌人 |
| `MAX_CORPSES` | 18 | 场上最大尸体数 |
| `MAX_PROJECTILES` | 24 | 场上最大投射物数 |
| `SPAWN_PADDING` | 32 | 敌人在边缘生成时距离边缘的内缩值 |
| `TIP_UPDATE_INTERVAL` | 250 | 底部提示最小刷新间隔 |
| `SKELETON_FOLLOW_DISTANCE` | 150 | 骷髅距离法师超过该值时优先回防 |
| `RESURRECT_DISTANCE` | 60 | 尸体可复活提示圈的视觉半径 |
| `XP_BASE_REQUIREMENT` | 30 | 无限模式经验需求基础值 |
| `XP_PER_NORMAL` | 10 | 普通敌人经验 |
| `XP_PER_MEDIUM` | 18 | 中型敌人经验 |
| `XP_PER_RANGER` | 14 | 远程敌人经验 |
| `ICE_SPIKE_INTERVAL` | 5200 | 冰刺基础释放间隔 |
| `ICE_SPIKE_SPEED` | 5.6 | 冰刺基础速度 |
| `ICE_FREEZE_DURATION` | 3000 | 冰冻基础持续时间 |
| `SHOCKWAVE_DURATION` | 520 | 冲击波动画持续时间 |
| `LEADERBOARD_KEY` | `necromancerLegionLeaderboard.v1` | 本机排行榜 localStorage key |
| `LEADERBOARD_LIMIT` | 5 | 每个模式最多保留 5 条记录 |

一个重要细节：`RESURRECT_DISTANCE` 当前只用于尸体附近的发光视觉圈。真正判断能否复活的函数是 `canResurrectCorpse()`，它使用的是尸体半径加死灵法师半径，也就是“主角与尸体发生接触”的距离。

## 七、全局状态

`gameState` 保存所有运行时状态：

| 字段 | 作用 |
|---|---|
| `running` | 游戏主循环是否运行 |
| `gameMode` | 当前模式，`normal` 或 `endless` |
| `currentWave` | 当前波数，按击杀数计算 |
| `kills` | 当前击杀数 |
| `level` | 无限模式等级 |
| `xp` | 当前经验 |
| `xpToNextLevel` | 升级所需经验 |
| `pendingSkillChoice` | 是否正在等待选择技能 |
| `skillLevels` | 三个技能等级：`shockwave`、`ice`、`command` |
| `shockwaveReady` | 冲击波是否待命 |
| `shockwaveUsed` | 冲击波是否已经消耗 |
| `lastIceSpikeTime` | 上次释放冰刺的时间 |
| `shockwaves` | 当前冲击波动画列表 |
| `necromancer` | 死灵法师实例 |
| `skeletons` | 己方骷髅单位数组 |
| `enemies` | 敌方单位数组 |
| `corpses` | 尸体数组 |
| `projectiles` | 投射物数组，包含普通远程弹和技能冰刺 |
| `gameStartTime` | 本局开始时间 |
| `lastTime` | 上一帧时间，用于计算 delta |
| `lastSpawnTime` | 上次刷怪时间 |
| `lastTipUpdate` | 上次底部提示更新时间 |
| `lastTipText` | 上次底部提示文本 |
| `lastTipReady` | 底部提示是否处于可复活高亮状态 |
| `mouseX` / `mouseY` | 当前鼠标或触摸目标坐标 |
| `clickRipples` | 点击反馈波纹数组 |

## 八、坐标与时间

Canvas 逻辑坐标固定为 375x667。鼠标和触摸事件会通过 `getBoundingClientRect()` 把屏幕坐标换算为 Canvas 逻辑坐标：

```text
canvasX = (clientX - rect.left) * canvas.width / rect.width
canvasY = (clientY - rect.top) * canvas.height / rect.height
```

主循环使用 `requestAnimationFrame(gameLoop)`。每帧计算：

```text
deltaTime = currentTime - lastTime
frameScale = clamp(deltaTime / 16.67, 0, 2)
```

这样在不同帧率下，单位移动和投射物速度会尽量保持一致；同时 `frameScale` 最大限制为 2，避免页面卡顿后下一帧移动过大。

游戏中同时使用了 `performance.now()` 和 `Date.now()`：

- `performance.now()` 用于帧时间、开局计时、技能间隔、冻结持续时间和 UI 提示节流。
- `Date.now()` 用于攻击冷却、尸体生命周期和排行榜记录时间戳。

## 九、单位基础类

`Unit` 是所有可战斗实体的基础类。

构造参数：

```text
x, y, hp, maxHp, attack, speed, color, size
```

公共能力：

- `drawHealthBar()`：绘制血条，血量高于 50% 为绿色，25%-50% 为黄色，低于 25% 为红色。
- `takeDamage(damage)`：扣血，返回是否死亡。
- `isAlive()`：判断血量是否大于 0。
- `distanceTo(other)`：计算到另一个单位的欧氏距离。
- `collidesWith(other)`：判断两个圆形单位是否碰撞。
- `separateFromOthers(units)`：把重叠单位推开，并限制在画布内。

速度在构造时会乘以 `CONFIG.MOVEMENT_SCALE`，所以类里传入的是“设计速度”，实际移动速度更小。

## 十、玩家角色：死灵法师

`Necromancer` 继承 `Unit`。

初始属性：

| 属性 | 值 |
|---|---:|
| 位置 | 画布中心 |
| hp/maxHp | 999/999 |
| attack | 0 |
| speed | 4，经 `MOVEMENT_SCALE` 缩放 |
| color | `#5c4a7d` |
| size | 26 |

移动方式不是直接瞬移到鼠标，而是每帧向 `gameState.mouseX/mouseY` 插值靠近：

```text
当前坐标 += (目标坐标 - 当前坐标) * 0.512
```

所以操作手感是“拖动目标点，法师快速跟随”。法师被限制在 Canvas 内，不能越界。

绘制方式：

- 外层紫色圆。
- 深紫色内圆。
- 两只浅色眼睛。
- 两个深色瞳孔。

胜负关键规则：任意存活敌人与死灵法师发生圆形碰撞时，普通情况下立即失败；如果无限模式中有待命冲击波，则先触发冲击波清屏并免死一次。

## 十一、己方骷髅

游戏有三类己方单位：普通骷髅、中型骷髅、远程骷髅。

### 普通骷髅 `Skeleton`

| 属性 | 值 |
|---|---:|
| hp/maxHp | 55/55 |
| attack | 18 |
| speed | 3.2，经缩放 |
| size | 16 |
| type | `melee` |

行为：

- 如果距离死灵法师超过 `SKELETON_FOLLOW_DISTANCE`，优先回到死灵法师附近。
- 否则寻找最近敌人。
- 如果距离目标超过自身半径、目标半径和 `ATTACK_RANGE` 的和，就向目标移动。
- 如果进入攻击距离，按攻击冷却扣目标血。
- 每帧会与其他己方单位分离，减少重叠。

绘制为白灰色骷髅头，带眼窝、鼻孔和血条。

### 中型骷髅 `MediumSkeleton`

| 属性 | 值 |
|---|---:|
| hp/maxHp | 100/100 |
| attack | 30 |
| speed | 2.2，经缩放 |
| size | 24 |
| type | `medium` |

行为和普通骷髅基本相同，但血量更高、伤害更高、速度更慢、体型更大。

绘制为棕色大型骷髅，带更粗描边和头冠式线条。

### 远程骷髅 `RangerSkeleton`

| 属性 | 值 |
|---|---:|
| hp/maxHp | 40/40 |
| attack | 15 |
| speed | 2.0，经缩放 |
| size | 14 |
| type | `ranger` |

行为：

- 距离死灵法师过远时回防。
- 否则寻找最近敌人。
- 如果距离敌人大于 `RANGER_RANGE`，向敌人靠近。
- 如果距离敌人小于 `RANGER_RANGE * 0.5`，向反方向后撤。
- 在 `RANGER_RANGE` 内按 `RANGER_COOLDOWN` 发射普通投射物。

绘制为绿色小骷髅，额外有弧线表示远程单位。

## 十二、敌人

敌人也有三类：普通敌人、中型敌人、远程外观敌人。三者都会追击死灵法师，若移动路径被骷髅挡住，则攻击挡路骷髅。

### 普通敌人 `Enemy`

| 属性 | 公式 |
|---|---|
| hp/maxHp | `35 + wave * 12` |
| attack | `12 + wave` |
| speed | `2.8 * MOVEMENT_SCALE * speedMultiplier` |
| size | 15 |
| type | `normal` |

绘制为紫色圆形怪物，黄眼睛，黑瞳孔，带血条和冰冻覆盖效果。

### 中型敌人 `MediumEnemy`

| 属性 | 公式 |
|---|---|
| hp/maxHp | `70 + wave * 18` |
| attack | `22 + wave` |
| speed | `2.0 * MOVEMENT_SCALE * speedMultiplier` |
| size | 22 |
| type | `medium` |

绘制为更大的紫色怪物，橙色眼睛。

### 远程外观敌人 `RangerEnemy`

| 属性 | 公式 |
|---|---|
| hp/maxHp | `25 + wave * 8` |
| attack | `15 + wave` |
| speed | `2.2 * MOVEMENT_SCALE * speedMultiplier` |
| size | 13 |
| type | `ranger` |

虽然名字是 RangerEnemy，但当前实现不会远程射击。它仍然使用 `chaseNecromancer()` 追击死灵法师，只是在外观上有弧线标识，并且经验值按远程敌人计算。

## 十三、敌人追击和阻挡

敌人公共追击逻辑在 `chaseNecromancer()` 中：

1. 如果敌人处于冰冻状态，直接停止。
2. 计算敌人到死灵法师的方向和距离。
3. 按速度与 `frameScale` 得出下一步位置。
4. 调用 `findBlockingSkeleton()` 检查下一步是否会撞上己方骷髅。
5. 如果有挡路骷髅，调用 `attackBlockingSkeleton()` 攻击它。
6. 如果没有阻挡，就向死灵法师移动。
7. 最后与其他敌人执行分离，减少重叠。

这个设计让骷髅既是输出单位，也是肉盾。敌人不会无视骷髅直接穿过，而会被挡住并消耗骷髅血量。

## 十四、尸体与复活

敌人死亡后由 `defeatEnemy()` 生成 `Corpse`，尸体位置等于敌人死亡位置。

尸体属性：

| 属性 | 值 |
|---|---:|
| size | 19 |
| lifetime | 8000 毫秒 |
| createdAt | 创建时的 `Date.now()` |

尸体最多保留 `MAX_CORPSES` 个。超过 18 个时，最旧尸体会被移除。

尸体会随时间淡出。剩余时间仍在，但透明度按生命周期进度降低，最低不是完全透明，而是 `1 - progress * 0.4`。

当尸体可被复活时，绘制会出现：

- 绿色半透明圆形光圈。
- 更亮的尸体描边。
- 尸体下方剩余秒数，例如 `7s`。

复活条件：

- 游戏正在运行。
- 场上有可复活尸体。
- 死灵法师和尸体圆形接触。
- 当前军队数量小于 `MAX_ARMY`。

玩家点击 Canvas 时，`handleCanvasClick()` 会检查 `countNearbyCorpses()`。如果有可复活尸体，则调用 `resurrectAllCorpses()`，一次性复活所有“与死灵法师接触”的尸体，直到军队达到上限。

复活生成单位的概率：

| 随机区间 | 生成单位 |
|---|---|
| `< 0.5` | 普通骷髅 |
| `0.5 - 0.8` | 中型骷髅 |
| `>= 0.8` | 远程骷髅 |

成功复活后：

- 新骷髅加入 `gameState.skeletons`。
- 对应尸体从 `gameState.corpses` 删除。
- 军队 UI 更新。
- 底部提示短暂显示 `复活成功 +N`。
- 点击位置出现绿色波纹。

如果点击时没有可复活尸体，会出现黄色点击波纹。

## 十五、投射物

### 普通投射物 `Projectile`

由远程骷髅发射。

属性：

- 起点为远程骷髅当前位置。
- 目标为某个敌人对象。
- 伤害来自远程骷髅攻击力。
- 速度为 `7 * MOVEMENT_SCALE`。
- size 为 4。

行为：

- 如果目标不存在或已死亡，投射物失效。
- 每帧朝目标当前位置移动，属于追踪弹。
- 碰到目标后扣血并失效。
- 如果飞出画布，也会失效。

绘制为紫色圆形弹体，带浅紫描边。

### 技能投射物 `SkillProjectile`

由无限模式技能“冰冻术”自动释放。

属性：

- 起点为死灵法师当前位置。
- 方向为固定角度。
- 不追踪目标。
- 速度为 `ICE_SPIKE_SPEED * MOVEMENT_SCALE`。
- size 为 5。
- type 为 `ice`。

行为：

- 沿固定方向直线飞行。
- 命中任意存活敌人后，设置敌人的 `frozenUntil`。
- 命中后立即失效。
- 超出画布外 20 像素后失效。

绘制为蓝白色尖刺。

## 十六、背景渲染

游戏背景不是图片，而是用离屏 Canvas 预渲染出来。

`backgroundCanvas` 和 `backgroundCtx` 是单独创建的离屏画布，尺寸同主画布。`renderBackground()` 只在初始化时调用一次：

- 先铺底色 `#2d3a2d`。
- 绘制 60 个暗色圆点，形成地面颗粒。
- 绘制 8 个灰色椭圆石块。
- 绘制 20 条暗绿色线条，形成地面划痕。

主循环每帧调用 `drawBackground()`，把离屏背景画到主 Canvas 上。这样背景不用每帧重新计算所有纹理元素，性能更好。

## 十七、HUD 与动态提示

`uiElements` 缓存了所有 DOM 节点，避免每次更新时重复查询。

### 军队显示

`updateArmyUI()` 设置：

```text
军队 当前数量/20
```

并强制刷新底部提示。

### 击杀与进度

普通模式：

- `#xpPanel` 隐藏。
- `#killCount` 显示 `击杀 当前/500`。
- 进度条按击杀数 / 500 更新。

无限模式：

- `#xpPanel` 显示。
- `#killCount` 只显示 `击杀 当前`。
- 进度条由 `updateXpUI()` 改为显示经验进度。

### 波次显示

`updateWaveUI()` 显示：

```text
第 N 波
```

波次并不是独立倒计时，而是由击杀数推导：

```text
waveNum = floor(kills / 50) + 1
```

### 底部提示

`updateBottomTip()` 根据状态选择文案：

| 条件 | 文案 |
|---|---|
| 正在选择技能 | `选择一个技能后继续战斗` |
| 游戏未运行 | `拖动移动，穿过尸体后点击复活` |
| 军队满员 | `军团已满，继续清理敌人` |
| 附近有尸体且有空位 | `点击复活 N 个尸体` |
| 有尸体但不在附近 | `主角球碰到尸体后点击复活` |
| 其他情况 | `拖动躲避敌人，军团会自动攻击` |

底部提示每 250ms 最多自动刷新一次。可复活时会给 `#bottomTip` 添加 `.ready` 类，使提示变亮并略微上移。

实现细节：`点击复活 N 个尸体` 中的 N 使用的是 `Math.min(gameState.corpses.length, availableSlots)`，不是附近尸体数量。因此当场上尸体很多但只有少数接触死灵法师时，提示数字可能比实际可复活数量偏大。

## 十八、敌人生成

刷怪入口是 `spawnEnemies()`。游戏开始时立即刷一轮，之后主循环中每隔 `SPAWN_INTERVAL` 即 900ms 尝试刷怪。

刷怪步骤：

1. 根据模式计算当前允许的在场敌人上限。
2. 如果敌人数量已达到上限，则本轮不刷。
3. 根据击杀进度计算当前波次。
4. 根据击杀进度、基础数量、倍率、波次成长和时间成长计算请求刷怪数量。
5. 实际刷怪数量不能超过剩余敌人槽位。
6. 每个敌人用 `setTimeout()` 间隔 550ms 生成，避免一瞬间全部出现。
7. 每个敌人在四条边之一随机生成。
8. 按概率生成三类敌人。

敌人生成概率：

| 随机区间 | 敌人类型 |
|---|---|
| `< 0.5` | 普通敌人 |
| `0.5 - 0.8` | 中型敌人 |
| `>= 0.8` | 远程外观敌人 |

边缘生成位置：

- 上边：`y = padding`
- 右边：`x = width - padding`
- 下边：`y = height - padding`
- 左边：`x = padding`

`padding` 为 32。

无限模式中，敌人上限、速度和数量会随等级、波次和时间进一步提高。

## 十九、成长与难度

敌人速度倍率：

```text
1
+ (wave - 1) * ENEMY_SPEED_GROWTH_PER_WAVE
+ elapsedMinutes * ENEMY_SPEED_GROWTH_PER_MINUTE
+ endlessPressure
```

无限模式的速度压力：

```text
level * 0.018
```

敌人数量倍率：

```text
1
+ (wave - 1) * ENEMY_COUNT_GROWTH_PER_WAVE
+ elapsedMinutes * ENEMY_COUNT_GROWTH_PER_MINUTE
+ endlessPressure
```

无限模式的数量压力：

```text
level * 0.025
```

普通模式最大在场敌人为 28。无限模式基础也是 28，但会逐步增长，最高 45：

```text
MAX_ACTIVE_ENEMIES + floor((currentWave - 1) * 1.4 + elapsedMinutes * 2)
```

## 二十、经验与技能

经验系统只在无限模式启用。普通模式击杀不会触发升级和技能选择。

经验来源：

| 敌人类型 | 经验 |
|---|---:|
| 普通敌人 | 10 |
| 中型敌人 | 18 |
| 远程外观敌人 | 14 |

升级需求由 `getXpRequirement(level)` 计算：

```text
round(30 + level * 8 + level^1.35 * 5)
```

每次击杀后调用 `addExperience()`。如果经验达到升级需求，就扣除需求经验、等级 +1、重新计算下一级需求。

当等级是 5 的倍数时，打开技能选择弹窗。此时：

- `pendingSkillChoice = true`
- `running = false`
- 主循环暂停
- 玩家必须选择一个技能后继续

### 技能一：冲击波

第一次选择时文案是：

```text
获得一次免死，首次死亡时清除全屏怪物。
```

再次选择时文案是：

```text
重新获得一次免死清屏机会。
```

效果：

- 设置 `shockwaveReady = true`。
- 当敌人与死灵法师碰撞时，如果冲击波待命，调用 `triggerShockwave()`。
- 冲击波会在法师位置创建一个扩张圆环动画。
- 冲击波会对场上所有敌人调用 `defeatEnemy(enemy, true)`，相当于清屏并正常给击杀和经验。
- 触发后 `shockwaveReady = false`，`shockwaveUsed = true`。

### 技能二：冰冻术

第一次选择时文案是：

```text
每隔数秒随机方向释放冰刺，冻结命中的怪物 3 秒。
```

升级规则：

- 奇数升级时增加一个新的冰刺发射方向。
- 偶数升级时冻结时间延长 0.8 秒。
- 冰刺释放间隔随等级缩短，但最低不低于 2600ms。

方向数量：

```text
1 + floor(level / 2)
```

冻结时间：

```text
3000 + floor((level - 1) / 2) * 800
```

### 技能三：亡魂号令

第一次选择时文案是：

```text
提升亡灵移动速度和攻击频率。
```

升级文案：

```text
亡灵移动和攻击频率小幅提高。
```

效果：

- 己方单位移动步长增加 `commandLevel * 7%`。
- 攻击冷却按 `baseCooldown * (1 - commandLevel * 0.055)` 缩短。
- 攻击冷却最低限制为 260ms。

## 二十一、模式与结算

### 普通模式

普通模式由 `startGame('normal')` 启动。

规则：

- 初始 5 个己方单位。
- 击杀目标为 500。
- 没有经验面板。
- 没有技能选择。
- 玩家被敌人接触后失败。
- 击杀数达到 500 后通关。

通关时：

- `running = false`
- 调用 `recordScore({ completed: true })`
- 显示 `#winPopup`

失败时：

- `running = false`
- 调用 `recordScore({ completed: false })`
- 显示 `#losePopup`

### 无限模式

无限模式由 `startGame('endless')` 启动。

规则：

- 初始也是 5 个己方单位。
- 没有 500 击杀通关。
- 显示经验和技能面板。
- 击杀敌人获得经验。
- 每 5 级选择一次技能。
- 难度随时间、波次和等级增加。
- 死亡后记录成绩并显示失败弹窗。

无限模式排行榜不关心 `completed`，主要排序依据是击杀数、等级和存活时间。

## 二十二、排行榜

排行榜使用浏览器 `localStorage`。key 为：

```text
necromancerLegionLeaderboard.v1
```

数据结构：

```json
{
  "normal": [],
  "endless": []
}
```

每条记录包含：

```json
{
  "kills": 53,
  "level": 3,
  "seconds": 124,
  "completed": false,
  "recordedAt": 1790000000000
}
```

`loadLeaderboards()` 会容错：

- 没有记录时返回空榜。
- JSON 解析失败时返回空榜。
- `normal` 或 `endless` 不是数组时替换为空数组。

`saveLeaderboards()` 也容错。如果浏览器限制存储，错误会被捕获，不会让游戏崩溃。

排序规则：

普通模式：

1. 击杀数更高排前。
2. 击杀相同，通关记录排在失败记录前。
3. 仍相同，用时更短排前。

无限模式：

1. 击杀数更高排前。
2. 击杀相同，等级更高排前。
3. 仍相同，存活时间更长排前。

每个模式最多保留 5 条。

## 二十三、输入交互

游戏支持鼠标和触摸。

### 鼠标移动

`mousemove` 调用 `updateMousePosition()`，更新死灵法师目标坐标。死灵法师下一帧向该坐标跟随移动。

### 触摸移动

`touchmove` 阻止默认滚动行为，然后取第一个触点并复用 `updateMousePosition()`。

### 鼠标点击

`click` 调用 `handleCanvasClick()`：

- 游戏未运行时忽略。
- 把点击位置换算为 Canvas 坐标。
- 如果附近有尸体，尝试复活。
- 有复活目标时显示绿色波纹。
- 没有复活目标时显示黄色波纹。

### 触摸点击

`touchstart` 阻止默认行为，然后把触摸事件转换成一个 `MouseEvent('click')` 派发给 Canvas。因此触摸点击复用鼠标点击逻辑。

### UI 按钮

菜单和弹窗按钮通过 `onclick` 直接调用全局函数：

- `startGame('normal')`
- `startGame('endless')`
- `openLeaderboard()`
- `closeLeaderboard()`
- `restartGame()`
- `returnToMainMenu()`

技能按钮由 JavaScript 动态创建，点击后调用 `chooseSkill(option.id)`。

## 二十四、主循环

`gameLoop(currentTime)` 是整个游戏的核心。运行顺序如下：

1. 如果 `running` 为 false，直接返回。
2. 计算 `deltaTime` 和 `frameScale`。
3. 更新死灵法师位置。
4. 更新所有存活骷髅。
5. 更新所有存活敌人。
6. 更新所有投射物，移除失效投射物。
7. 尝试释放冰刺。
8. 检查敌人与死灵法师碰撞。
9. 如果碰撞且冲击波可用，则触发冲击波。
10. 如果碰撞且没有冲击波，则记录失败、显示失败弹窗、退出循环。
11. 扫描死亡敌人，调用 `defeatEnemy()`。
12. 普通模式中如果击杀数达到 500，记录通关、显示通关弹窗、退出循环。
13. 如果升级导致技能选择弹窗打开，退出当前循环，等待玩家选择。
14. 移除死亡骷髅并更新军队 UI。
15. 移除过期尸体。
16. 更新底部提示。
17. 达到刷怪间隔时刷怪。
18. 绘制背景。
19. 绘制尸体。
20. 绘制投射物。
21. 绘制冲击波。
22. 绘制死灵法师。
23. 绘制骷髅。
24. 绘制敌人。
25. 绘制点击波纹。
26. 请求下一帧。

简化流程：

```text
输入目标点
  -> 法师跟随
  -> 骷髅寻敌/攻击
  -> 敌人追法师/打挡路骷髅
  -> 投射物命中
  -> 死亡敌人变尸体
  -> 玩家点击尸体复活
  -> 击杀/经验/技能/排行榜更新
  -> Canvas 重绘
```

## 二十五、开始、重开与返回主菜单

### `startGame(mode)`

启动新局时会：

- 隐藏开始、胜利、失败、排行榜和技能弹窗。
- 设置 `running = true`。
- 设置当前模式。
- 重置击杀、等级、经验、技能、敌人、尸体、投射物、点击波纹和冲击波。
- 创建死灵法师。
- 围绕法师生成 5 个初始己方单位。
- 初始 5 个单位中，第 1 个是中型骷髅，第 2 个是远程骷髅，其余 3 个是普通骷髅。
- 重置鼠标目标为画布中心。
- 更新 UI。
- 立即刷一轮敌人。
- 启动 `requestAnimationFrame(gameLoop)`。

### `restartGame()`

隐藏当前结算和覆盖弹窗，然后用当前 `gameMode` 重新调用 `startGame()`。

### `returnToMainMenu()`

返回菜单时会：

- 停止游戏。
- 模式重置为普通模式。
- 清空所有运行时实体。
- 重置击杀、等级、经验、波次和目标坐标。
- 隐藏其他弹窗。
- 显示开始菜单。
- 重绘背景。
- 更新 UI 和排行榜。

## 二十六、绘制层级

每帧 Canvas 绘制顺序很重要：

1. 背景
2. 尸体
3. 投射物
4. 冲击波
5. 死灵法师
6. 己方骷髅
7. 敌人
8. 点击波纹

这意味着：

- 尸体位于单位下方。
- 投射物和冲击波位于背景和尸体上方。
- 法师会被之后绘制的骷髅或敌人覆盖。
- 敌人绘制在骷髅之后，因此敌人可能视觉上压在骷髅上方。
- 点击波纹永远在最上层。

## 二十七、视觉反馈

当前游戏有以下反馈：

- 尸体可复活时出现绿色范围光圈。
- 尸体可复活时显示剩余秒数。
- 底部提示可复活时变亮并上移。
- 点击成功复活时出现绿色波纹。
- 点击无复活目标时出现黄色波纹。
- 普通远程弹是紫色圆点。
- 冰刺是蓝白色尖刺。
- 冰冻敌人会覆盖蓝色圆形光效。
- 冲击波是从法师位置向外扩张的绿色圆环。
- 按钮有 hover 上移和 active 下压反馈。
- 开始菜单有扫描光线和按钮扫光动画。

## 二十八、素材说明

### `necromancer-legion-poster-start.png`

尺寸 750x1334，透明通道格式为 32 位 ARGB。当前作为开始菜单背景图。视觉内容包括：

- 顶部大标题《死灵军团》。
- 副标题“召唤亡者 · 横扫战场”。
- 中部游戏画面示意，包含骷髅、敌人、尸体倒计时、击杀 UI 和复活点击提示。
- 底部“召唤亡灵大军”等宣传文字。

因为 CSS 使用 `center / cover`，这张图会裁切适配容器。当前 750x1334 与游戏 375x667 等比例，适合作为竖屏背景。

### `necromancer-legion-poster-clean.png`

尺寸 1024x1536，32 位 ARGB。代码未直接引用。视觉内容是完整宣传海报，包含：

- 顶部标题和暗黑城堡背景。
- 中央游戏截图框。
- 左右四个玩法卖点：初始小兵、召唤亡灵、击杀怪物、500 击杀目标。
- 底部多个图标卖点，包括轻松上手、策略召唤、无尽挑战、目标明确等。

### `necromancer-legion-poster.png`

尺寸 1024x1536，24 位 RGB。代码未直接引用。整体内容与 clean 版本类似，但中上部包含“前十名通关奶茶一杯!”横幅，适合比赛、活动或线下展示场景。

## 二十九、依赖与浏览器能力

项目使用的浏览器能力：

- HTML5 Canvas 2D API。
- DOM API。
- CSS 渐变、动画、滤镜和 `backdrop-filter`。
- `localStorage`。
- `requestAnimationFrame()`。
- `performance.now()`。
- 鼠标事件和触摸事件。

没有使用：

- npm 包。
- 前端框架。
- 模块化 import/export。
- WebAudio。
- 图片预加载逻辑。
- 服务端接口。
- 网络请求。

## 三十、已知实现细节与潜在改进点

以下不是错误结论，而是从当前实现中可以看到的具体特征：

- `RESURRECT_DISTANCE` 是视觉提示圈半径，但复活判定用的是法师半径加尸体半径。玩家看到大光圈时，可能仍需要让法师球体真正碰到尸体才能复活。
- `updateBottomTip()` 在显示“点击复活 N 个尸体”时，N 使用场上尸体总数而不是附近尸体数，提示可能偏大。
- `RangerEnemy` 不具备远程攻击行为，只是外观和经验分类上的“远程”敌人。
- 所有代码都在一个 HTML 文件中，便于快速展示，但后续扩展时会让配置、实体类、UI、排行榜和主循环混在一起。
- 排行榜只保存在本机浏览器，清空浏览器数据或换浏览器会丢失。
- 资源中有两张海报未被代码使用，可能是备用宣传素材。
- 游戏没有暂停按钮，技能选择会通过 `running = false` 临时暂停无限模式。
- 游戏没有音效。
- 游戏没有移动端虚拟摇杆，触摸移动直接跟随手指位置。
- 游戏没有主动防止多次 `requestAnimationFrame` 重入的全局循环 id；不过主要路径会在 `running` 为 false 时返回。
- 敌人刷出使用多个 `setTimeout()` 分批生成，如果游戏在延迟期间停止，回调里会检查 `running`，避免继续刷怪。
- `recordedAt` 被存进排行榜，但当前渲染排行榜时没有显示日期。

## 三十一、适合后续开发的拆分方向

如果后续继续扩大项目，可以把当前单文件拆成：

- `config.js`：所有 `CONFIG`。
- `state.js`：`gameState` 和重置逻辑。
- `entities/unit.js`：`Unit` 基类。
- `entities/necromancer.js`：死灵法师。
- `entities/skeletons.js`：己方三类骷髅。
- `entities/enemies.js`：三类敌人和追击逻辑。
- `entities/corpse.js`：尸体和复活判定。
- `entities/projectiles.js`：普通投射物与技能投射物。
- `systems/spawn.js`：刷怪、波次和难度成长。
- `systems/skills.js`：无限模式技能。
- `systems/leaderboard.js`：本机排行榜。
- `systems/input.js`：鼠标和触摸输入。
- `systems/render.js`：背景和绘制顺序。
- `ui.js`：DOM 查询、HUD、弹窗和提示。
- `main.js`：启动和主循环。

当前项目为了比赛或快速演示，单文件更方便；如果团队协作或继续加功能，拆分会更容易维护。

## 三十二、文档覆盖结论

当前游戏的运行主体只有一个 HTML 文件，资源目录有三张 PNG。本文档覆盖了：

- 全部项目文件及用途。
- 页面 DOM 结构。
- CSS 视觉层级。
- Canvas 坐标和渲染流程。
- 所有核心配置。
- 全局状态字段。
- 全部实体类。
- 全部核心系统函数。
- 普通模式、无限模式和结算。
- 经验、技能和排行榜。
- 输入事件。
- 素材内容。
- 已知实现细节。

这份文档可作为之后继续优化视觉、手感、玩法数值、代码拆分或提交项目说明的基础。
